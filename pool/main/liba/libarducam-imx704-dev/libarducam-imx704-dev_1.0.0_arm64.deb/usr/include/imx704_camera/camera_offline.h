/*
 *
 * dToF offline camera utilities
 */
#pragma once

#include <string>
#include <memory>
#include <cstddef>
#include "imx704_camera/frame_buffer.h"

namespace arducam
{
    namespace depthsense
    {
        class camera;
        class camera_stream;

        /** Create an offline camera */
        std::shared_ptr<camera> create_camera_offline(const std::string& name);

        /** Add an offline stream to a camera */
        void add_stream_offline(camera* cam, stream_type type, std::unique_ptr<camera_stream> stream);

    }  // namespace depthsense
}
