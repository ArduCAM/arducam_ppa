/*
 *
 * dToF camera_stream interface
 */
#pragma once

#include <vector>
#include <cstdint>

namespace arducam
{
    namespace depthsense
    {
        enum class stream_type
        {
            image,
            ebd
        };
        class camera_stream
        {
        public:
            virtual ~camera_stream() noexcept = default;
            virtual int open() = 0;
            virtual void close() = 0;
            virtual int start() = 0;
            virtual void stop() = 0;
            virtual int get_frame(std::vector<uint8_t>& raw_data, unsigned timeout_ms) = 0;
        };
    }  // namespace depthsense
}
