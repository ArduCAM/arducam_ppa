/*
 *
 * dToF Camera interface
 */

#include <string>
#include <unordered_map>

#include "imx704_camera/frame_buffer.h"

#pragma once

namespace arducam
{
    namespace depthsense
    {

        /**
         * @enum Define the camera synchronization mode
         */
        enum camera_sync_mode
        {
            camera_sync_undefined,
            camera_sync_master_mode,
            camera_sync_slave_mode
        };

        /**
         * @enum Camera status
         */
        enum camera_status
        {
            camera_status_available,  ///< camera can be acquired for exclusive access
            camera_status_idle,       ///< camera is acquired and ready to start streaming
            camera_status_streaming   ///< camera is streaming
        };

        /**
         * @struct Camera mode information
         */
        struct camera_mode_info
        {
            /** width sensor resolution */
            unsigned int sensor_width;
            /** Height sensor resolution */
            unsigned int sensor_height;
            /** Raw data: size of image data */
            unsigned int raw_size_image;
            /** Raw data: size of embedded data */
            unsigned int raw_size_ebd;
            /** Maximum number of echo */
            unsigned int max_echo;
            /** Camera works in dual depth mode */
            bool dual_depth_mode;
        };

        /**
         * @struct Parameters for dual depth mode
         */
        struct dual_depth_params
        {
            float select_near = 200.f;  ///< distance in millimeters below which a depth is considered to be near
            float select_far = 2000.f;  ///< distance in millimeters above which a depth is considered to be far
            float merge_window = 50.f;  ///< depths will be merged if they are within this range (in millimeters) of each other
        };

        /**
         * @struct Camera information
         */
        struct camera_info
        {
            /** Identifier from the current discovery result.
             * Device numbering may change across system reboots. */
            std::string id;
            /** camera model */
            std::string model;
            /** Camera status */
            camera_status status;
            /** Selected synchronization mode */
            camera_sync_mode sync_mode;
            /** Current camera mode */
            unsigned mode;
            /** True when current mode has dual depth */
            bool dual_depth_mode;
            /** Current number of echoes */
            unsigned number_of_echo;
            /** List of supported mode */
            std::unordered_map<unsigned, camera_mode_info> supported_modes;
            /** Current depth params */
            dual_depth_params depth_params;
        };

        /** status for the laser driver IC */
        struct laser_status_flags
        {
            bool light_emitted;    ///< laser light status (true when laser was emitted, false otherwise)
            bool read_back;        ///< read back status (false when error detected)
            bool lvds_connection;  ///< LVDS connection status (false when error detected)
            bool bank_check;       ///< bank check status (false when error detected)
            /// auto conversion to bool
            inline operator bool() const { return light_emitted && read_back && lvds_connection && bank_check; }
        };

        /**
         * @struct Real time sensor information obtained from the
         * embedded data stream
         */
        struct sensor_info
        {
            float temperature;                ///< sensor temperature
            uint32_t depth_num;               ///< number of depths to output
            uint32_t peak_order_selection;    ///< peak order selection
            laser_status_flags laser_status;  ///< status for the laser driver IC
        };

        class camera
        {
            /**
             *
             * The camera class implements a middleware between applications and camera hardware.
             * It captures the frames from a dtof camera, processes them, and generates
             * the point cloud data, the radial depth, the noise information
             * and many other useful information to the application layer.
             *
             * The camera is instantiated by the camera_manager and passed to the application
             * with the function camera_manager::get_camera(). The application can get the list of
             * camera with a call to camera_manager::get_camera_list().
             *
             * More details can be found in the README.md file
             */

        public:
            virtual ~camera() noexcept = default;

            /**
             * @brief Retrieve the camera info
             *
             * @return camera information
             */
            virtual const camera_info& get_camera_info() const = 0;

            /**
             * @brief Open and acquire the dToF camera device for exclusive access
             *
             * The camera must be available. Opening an already acquired camera
             * returns -EACCES; underlying pipeline and stream failures may propagate.
             *
             * Once exclusive access isn't needed anymore, the device should be released
             * with a call to the camera::close() function.
             *
             * @param[in] mode camera mode
             *
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not available
             * @retval -EINVAL The requested mode is unsupported
             */
            virtual int open(unsigned int mode) = 0;

            /**
             * @brief Release exclusive access and close the dToF camera device
             *
             * If streaming, stop capture before releasing resources.
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not acquired
             */
            virtual int close() = 0;

            /**
             * @brief Configure dToF camera device: dual depth
             * behavior. Only valid for dual modes (e.g. 301C)
             *
             * Call to configure_camera_dual_depth() is optional.
             * Can only be called before 'start'.
             *
             * @param[in] params the parameters to configure the depth mode
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not idle, or the current mode is not dual
             * @retval -EINVAL Thresholds are non-finite, negative, or near exceeds far
             */
            virtual int configure_camera_dual_depth(const dual_depth_params& params) = 0;

            // Synchronization control is not exposed until it is connected to
            // the camera hardware configuration path.
            // virtual int configure_camera_sync_mode(camera_sync_mode sync_mode) = 0;

            /**
             * @brief Define the number of echoes to be processed
             *
             * Call to configure_camera_echo() is optional, Default value is '1'
             * Can only be called before 'start'.
             *
             * @param[in] number_of_echoes number of echoes that shall be reported
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not in a state where it can be configured
             * @retval -EINVAL Not supported by the camera
             */
            virtual int configure_camera_echo(unsigned int number_of_echoes) = 0;

            /**
             * @brief Enable/Disable output processing
             *
             * The library generates different types of output from the sensor.
             * Each output requires some processing, so for performance optimization
             * the application should define which output shall be generated.
             *
             * Call to configure_camera_output() is optional, by default only the point cloud is enabled.
             * Can only be called before 'start'.
             *
             * @param[in] config output processing configuration
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not in a state where it can be configured
             * @retval -EINVAL Not supported by the camera
             */
            virtual int configure_camera_output(const camera_output_configuration& config) = 0;

            /**
             * @brief Start capture from camera
             *
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not in a state where it can be started
             */
            virtual int start() = 0;

            /**
             * @brief Stop capture from camera
             *
             * This function stops capturing and processing requests immediately.
             *
             * @return 0 on success or a negative error code otherwise
             * @retval -EACCES The camera is not running so can't be stopped
             */
            virtual int stop() = 0;

            /**
             * @brief Get frame from the camera
             *
             * This function returns a frame with the point_cloud and other optional data.
             * It is blocking call until the timeout, provided as argument, has expired.
             * Use timeout_ms=0 for a non-blocking call.
             * Application should check frame_buffer.error field to know if a frame was
             * filled, or if the timeout triggered, or if an error was reported.
             *
             * The application should not allocate frame buffers, they are allocated and managed by the camera class.
             * The frame_buffer object is returned as a reference from a call to `camera::get_frame()`.
             * This buffer is valid until the next get_frame(), start(), stop(), close(),
             * or camera destruction. Copy the content when the application needs it
             * for longer.
             * (The application should not try to free the camera_buffer)
             *
             * @param[in] timeout_ms function timeout in ms.
             * @return frame_buffer reference to a frame_buffer object where are stored the frame data.
             */
            virtual const frame_buffer& get_frame(unsigned int timeout_ms) = 0;

            /**
             * @brief Get real time sensor information
             *
             * This function returns real time sensor information.
             *
             * @retval sensor info
             */
            virtual const sensor_info& get_sensor_info() const = 0;
        };
    };  // namespace depthsense
};
