/*
 *
 * dToF Camera Manager interface
 */
#pragma once

#include <vector>
#include <string>
#include <memory>

#include <imx704_camera/camera.h>

namespace arducam
{
    namespace depthsense
    {

        class camera_manager
        {
            /**
             *
             * runs for the life of the application.
             * When the camera_manager starts, it enumerates all the cameras detected in the system.
             * Behind the scenes, it abstracts and manages the complex pipelines that kernel drivers expose through the
             * Linux Media Controller and Video for Linux (V4L2) APIs, meaning that an application doesn’t need to handle
             * device or driver specific details.
             *
             * manager instance at the beginning of the main function, then start it.
             * An application must only create a single Camera Manager instance.
             * The camera_manager can be stored in a unique_ptr to automate deleting the instance when it is no longer used,
             * but care must be taken to ensure all cameras are released explicitly before this happens.
             *
             * Attempting to create a second instance without first deleting the
             * existing instance results in undefined behavior.
             */

        public:
            // singleton implementation that lets clients access its unique instance.
            static camera_manager& getInstance();
            camera_manager(const camera_manager&) = delete;  // rule of three
            camera_manager& operator=(const camera_manager&) = delete;

            /**
             * @brief Initialize the camera manager
             *
             * The manager shall be started with init(). This will
             * present in the system, which can then be listed with
             * get_camera_list() and retrieved with get_camera().
             *
             * @return 0 on success or a negative error code otherwise
             */
            int init();

            /**
             * @brief Retrieve all available dToF cameras
             *
             * The camera information provides the camera index which shall be used in the open() function
             *
             * @return List of all available dToF cameras
             */
            std::vector<camera_info> get_camera_list() const;

            /**
             * @brief Get a camera based on ID
             *
             * @param[in] id ID of camera to get
             * @return Shared pointer to Camera object or nullptr if camera not found
             */
            std::shared_ptr<camera> get_camera(const std::string& id);

        private:
            camera_manager() = default;  // no public constructor
            ~camera_manager();           // no public destructor

            struct camera_instance
            {
                std::string id;
                std::shared_ptr<camera> cam;
            };
            std::vector<camera_instance> camera_list;
        };
    };  // namespace depthsense
};
