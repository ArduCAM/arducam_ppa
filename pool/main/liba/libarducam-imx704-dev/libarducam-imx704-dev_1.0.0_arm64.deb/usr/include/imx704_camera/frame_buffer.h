/*
 *
 * dToF Camera interface
 */

#include <stdint.h>
#include <vector>
#include <array>

#include "imx704_camera/vector3.h"
#include "imx704_camera/camera_stream.h"

#pragma once

namespace arducam
{
    namespace depthsense
    {
        /**
         * @struct Frame output configuration
         *
         * The library generates different type of output from the sensor.
         * Each output requires some processing, so for performance optimization
         * the application should define which output shall be generated.
         */
        struct camera_output_configuration
        {
            bool enable_point_cloud;      ///< enable point cloud processing
            bool enable_cartesian_depth;  ///< enable cartesian depth processing
            bool enable_radial_depth;     ///< enable radial depth processing
            bool enable_noise_level;      ///< enable noise level processing
            bool enable_peak_height;      ///< enable peak height processing
            bool enable_peak_status;      ///< enable peak status processing
            bool enable_histogram;        ///< enable histogram processing
            bool enable_pdc;              ///< enable pdc processing
        };

        /** Peak status enumeration. This is provided as part of the
         * @ref frame_buffer and provides information about the status
         * of the peaks in each pixel.
         */
        enum class peak_status : uint8_t
        {
            correct = 0,        ///< detection data is correct
            not_detected = 1,   ///< peak could not be detected
            out_of_range = 2,   ///< peak width is greater or less than specified
            bad_depth_num = 3,  ///< exceeded the specified number of depth_num
        };

        /**
         * @brief frame_buffer provides the processed camera frame
         */
        class frame_buffer
        {
        public:
            enum : size_t
            {
                histogram_size = 144,
                pdc_size = 4,
            };
            using histogram_type = std::array<uint32_t, histogram_size>;
            using pdc_type = std::array<uint32_t, pdc_size>;

        public:
            /**
             * @brief empty frame_buffer class constructor with error
             */
            frame_buffer(int error_) : error(error_) {}

            /**
             * @brief frame_buffer class constructor with buffer resizing
             *
             * @param[in] max_depth_index maximum number of echo
             * @param[in] frame_size frame size
             */
            frame_buffer(const camera_output_configuration& config, unsigned int max_depth_index, unsigned int frame_size);

            /**
             * @brief  Error number filled by `camera::get_frame()`
             *
             * value 0 : a frame is successfully received
             * value -ETIME : no frame received (timeout)
             * value -EACCES : The camera is not streaming
             */
            int error = 0;

            /**
             * @brief  Frame ID returned by the camera metadata
             */
            unsigned int frame_id = 0;

            /**
             * @brief  Timestamp returned by the camera metadata
             */
            unsigned int timestamp = 0;

            /**
             * @brief  Maximum depth index
             */
            uint8_t max_depth_index = 0;

        public:
            // these members can be made public, because the user only
            // sees a const object, and so cannot write to its members

            /**
             * @brief point cloud data buffer
             *
             * The point cloud consists of a buffer 3D vectors
             * one point cloud is allocated per echo.
             */
            std::vector<std::vector<vector3>> point_cloud;

            /**
             * @brief cartesian depth buffer
             *
             * The cartesian depth consists of a buffer 3D vectors
             * one cartesian depth is allocated per echo.
             */
            std::vector<std::vector<float>> cartesian_depth;

            /**
             * @brief radial depth buffer
             *
             * The radial depth consists of a float vector
             * one radial depth vector is allocated per echo.
             */
            std::vector<std::vector<float>> radial_depth;

            /**
             * @brief peak height buffer
             *
             * The peak height consists of a float vector
             * one peak height vector is allocated per echo.
             */
            std::vector<std::vector<float>> peak_height;

            /**
             * @brief peak status buffer
             *
             * The peak status consists of a peak_status vector
             * one peak status vector is allocated per echo.
             */
            std::vector<std::vector<peak_status>> peak_status_;

            std::vector<float> noise_level;

            std::vector<histogram_type> histogram;

            std::vector<pdc_type> pdc;

            std::vector<uint8_t> raw_image;
            std::vector<uint8_t> raw_ebd;
        };
    };  // namespace depthsense
};
