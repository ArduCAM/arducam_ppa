/*
 *
 * Defines basic vector types in 3 dimensions.
 */

#pragma once

#include <cassert>
#include <cmath>

namespace arducam
{
    namespace depthsense
    {

        /// Comparison type trait used to avoid comparing float directly
        template<typename T>
        struct comparator
        {
            using type = T;

            /// For non specialized version epsilon is 0
            static constexpr T epsilon = 0;

            /**
             *    \brief    Test if two value are equal within a given threshold
             *
             *    \param[in]    lhs            Left hand side to compare
             *    \param[in]    rhs            Right hand side to compare
             *    \param[in]    threshold    The threshold for the test (by default = epsilon)
             *
             *    \return    Return true if (lhs == rhs)
             *
             *    \warning The threshold is ignored for non specialized type.
             */
            static bool is_equal(const type lhs, const type rhs, const type /*threshold*/ = epsilon) { return lhs == rhs; }

            /**
            *    \brief    Test if a value is zero within a given threshold
            *
            *    \param[in]    t            The value to test
            *    \param[in]    threshold    The threshold for the test (by default = epsilon)
            *
            *    \return    Return true if (t == 0)
            *
            *    \warning The threshold is ignored for non specialized type.
            */
            static bool is_zero(const type t, const type /*threshold*/ = epsilon) { return t == 0; }
        };

        /// Comparison type trait specialized for float
        template<>
        struct comparator<float>
        {
            using type = float;

            /// Threshold to be considered equal for two float
            static constexpr type epsilon = 1.e-5f;

            /**
            *    \brief    Test if two value are equal within a given threshold
            *
            *    \param[in]    lhs            Left hand side to compare
            *    \param[in]    rhs            Right hand side to compare
            *    \param[in]    threshold    The threshold for the test (by default = epsilon)
            *
            *    \return    Return true if std::abs(lhs == rhs) < threshold
            */
            static bool is_equal(const type lhs, const type rhs, const type threshold = epsilon) { return std::abs(lhs - rhs) < threshold; }

            /**
            *    \brief    Test if a value is zero within a given threshold
            *
            *    \param[in]    t            The value to test
            *    \param[in]    threshold    The threshold for the test (by default = epsilon)
            *
            *    \return    Return true if std::abs(t) < threshold
            */
            static bool is_zero(const type t, const type threshold = epsilon) { return std::abs(t) < threshold; }
        };

        /// Comparison type trait specialized for float
        template<>
        struct comparator<double>
        {
            using type = double;

            /// Threshold to be considered equal for two double
            static constexpr type epsilon = 1.e-5;

            /**
            *    \brief    Test if two value are equal within a given threshold
            *
            *    \param[in]    lhs            Left hand side to compare
            *    \param[in]    rhs            Right hand side to compare
            *    \param[in]    threshold    The threshold for the test (by default = epsilon)
            *
            *    \return    Return true if std::abs(lhs == rhs) < threshold
            */
            static bool is_equal(const type lhs, const type rhs, const type threshold = epsilon) { return std::abs(lhs - rhs) < threshold; }

            /**
            *    \brief    Test if a value is zero within a given threshold
            *
            *    \param[in]    t            The value to test
            *    \param[in]    threshold    The threshold for the test (by default = epsilon)
            *
            *    \return    Return true if std::abs(t) < threshold
            */
            static bool is_zero(const type t, const type threshold = epsilon) { return std::abs(t) < threshold; }
        };

        /**
        *    \brief    A generic 3d vector
        *
        *    \tparam    T    The type of the element of the vector
        */
        template<typename T>
        class basic_vector3
        {
        public:
            /// Type of the element of the vector
            using value_type = T;

            /**
            *    \brief    Compare two vectors
            *
            *    \param[in]    lhs    Left hand side vector.
            *    \param[in]    rhs    Right hand side vector.
            *
            *    \return    True if the vectors are equivalent (with an epsilon if value type is floating point)
            */
            friend bool operator==(const basic_vector3& lhs, const basic_vector3& rhs)
            {
                return comparator<value_type>::is_equal(lhs.x, rhs.x) && comparator<value_type>::is_equal(lhs.y, rhs.y) &&
                       comparator<value_type>::is_equal(lhs.z, rhs.z);
            }

            /**
            *    \brief    Compare two vectors
            *
            *    \param[in]    lhs    Left hand side vector.
            *    \param[in]    rhs    Right hand side vector.
            *
            *    \return    False if the vectors are equivalent (with an epsilon if value type is floating point)
            */
            friend bool operator!=(const basic_vector3& lhs, const basic_vector3& rhs) { return !(lhs == rhs); }

            /**
            *    \brief    Addition operation between two vectors
            *
            *    \param[in]    lhs    Left hand side vector.
            *    \param[in]    rhs    Right hand side vector.
            *
            *    return A vector equal to lhs + rhs
            */
            friend basic_vector3 operator+(const basic_vector3& lhs, const basic_vector3& rhs)
            {
                basic_vector3 res = lhs;
                res += rhs;
                return res;
            }

            /**
            *    \brief    Subtraction operation between two vectors
            *
            *    \param[in]    lhs    Left hand side vector.
            *    \param[in]    rhs    Right hand side vector.
            *
            *    return A vector equal to lhs - rhs
            */
            friend basic_vector3 operator-(const basic_vector3& lhs, const basic_vector3& rhs)
            {
                basic_vector3 res = lhs;
                res -= rhs;
                return res;
            }

            /**
            *    \brief    Multiply a vector by a scalar.
            *
            *    \param[in]    v        The vector to multiply
            *    \param[in]    scalar    The scaling factor.
            *
            *    return A vector equal v * scalar
            */
            friend basic_vector3 operator*(const basic_vector3& v, const value_type scalar)
            {
                basic_vector3 res = v;
                res *= scalar;
                return res;
            }

            /**
            *    \brief    Multiply a scalar by vector.
            *
            *    \param[in]    scalar    The scaling factor.
            *    \param[in]    v        The vector to multiply
            *
            *    return A vector equal scalar * v
            */
            friend basic_vector3 operator*(const value_type scalar, const basic_vector3& v)
            {
                basic_vector3 res = v;
                res *= scalar;
                return res;
            }

            /**
            *    \brief    Divide a vector by a scalar.
            *
            *    \param[in]    v        The vector to divide
            *    \param[in]    scalar    The scaling factor.
            *
            *    return A vector equal mat / scalar
            */
            friend basic_vector3 operator/(const basic_vector3& v, const value_type scalar)
            {
                assert(!comparator<value_type>::is_zero(scalar));
                basic_vector3 res = v;
                res /= scalar;
                return res;
            }

            /**
            *    \brief    Return the memberwise product of two vectors
            *
            *    \param[in]    lhs    Left hand side vector.
            *    \param[in]    rhs    Right hand side vector.
            *
            *    return Memberwise product of the two given vectors
            */
            friend basic_vector3 operator*(const basic_vector3& lhs, const basic_vector3& rhs)
            {
                basic_vector3 res = lhs;
                res *= rhs;
                return res;
            }

            /**
            *    \brief    Add a vector to this vector
            *
            *    \param[in]    v    The vector to add
            *
            *    return This vector after the given vector has been added.
            */
            basic_vector3& operator+=(const basic_vector3& v)
            {
                x += v.x;
                y += v.y;
                z += v.z;
                return *this;
            }

            /**
            *    \brief    Subtract a vector to this vector
            *
            *    \param[in]    v    The vector to subtract
            *
            *    return This vector after the given vector has been subtract.
            */
            basic_vector3& operator-=(const basic_vector3& v)
            {
                x -= v.x;
                y -= v.y;
                z -= v.z;
                return *this;
            }

            /**
            *    \brief    Multiply this vector by a scalar
            *
            *    \param[in]    scalar    The scaling value
            *
            *    return This vector after it has been scaled.
            */
            basic_vector3& operator*=(const value_type scalar)
            {
                x *= scalar;
                y *= scalar;
                z *= scalar;
                return *this;
            }

            /**
            *    \brief    Divide this vector by a scalar
            *
            *    \param[in]    scalar    The scaling value
            *
            *    return This vector after it has been scaled.
            */
            basic_vector3& operator/=(const value_type scalar)
            {
                assert(!comparator<value_type>::is_zero(scalar));
                x /= scalar;
                y /= scalar;
                z /= scalar;
                return *this;
            }

            /**
            *    \brief    Multiply (memberwise) this vector by a vector
            *
            *    \param[in]    v    The vector to multiply by.
            *
            *    return This vector after it has been multiply by the given vector.
            */
            basic_vector3& operator*=(const basic_vector3& v)
            {
                x *= v.x;
                y *= v.y;
                z *= v.z;
                return *this;
            }

            /**
            *    \brief    Return the ith element of the vector
            *
            *    \param[in]    i    The index to access
            *
            *    \return    Return the ith element of the vector.
            *
            *    This method allow access to the elements of the vector by index (x = 0, y = 1)
            */
            value_type& operator[](const std::size_t i)
            {
                assert(i < 3);
                return (&x)[i];
            }

            /**
            *    \brief    Return the ith element of the vector
            *
            *    \param[in]    i    The index to access
            *
            *    \return    Return the ith element of the vector.
            *
            *    This method allow access to the elements of the vector by index (x = 0, y = 1, z = 2)
            */
            const value_type& operator[](const std::size_t i) const
            {
                assert(i < 3);
                return (&x)[i];
            }

            /**
            *    \brief    Bring the current vector to a target floor value.
            *
            *    \param[in]    target    The target floor value
            *
            *    Each element of the vector that is bigger that the target's corresponding element is floored to the target's value.
            */
            void make_floor(const basic_vector3& target)
            {
                if (target.x < x)
                {
                    x = target.x;
                }
                if (target.y < y)
                {
                    y = target.y;
                }
                if (target.z < z)
                {
                    z = target.z;
                }
            }

            /**
            *    \brief    Bring the current vector to a target ceil value.
            *
            *    \param[in]    target    The target ceil value
            *
            *    Each element of the vector that is smaller that the target's corresponding element is ceiled to the target's value.
            */
            void make_ceil(const basic_vector3& target)
            {
                if (target.x > x)
                {
                    x = target.x;
                }
                if (target.y > y)
                {
                    y = target.y;
                }
                if (target.z > z)
                {
                    z = target.z;
                }
            }

            /// The x value of the vector.
            value_type x;
            /// The y value of the vector.
            value_type y;
            /// The z value of the vector.
            value_type z;
        };

        using vector3 = basic_vector3<float>;
        using vector3i = basic_vector3<int32_t>;
    };  // namespace depthsense
}
