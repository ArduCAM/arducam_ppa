#ifndef __TOF_SENSOR_H
#define __TOF_SENSOR_H

#include "ArducamTOFUnity.hpp"

namespace Arducam
{
/**
 * @brief Direct operation class for camera/
 */
class ArducamTOFSensor
{
  public:
    /**
     * @brief the count of the frame needed to be fetched once.
     */
    int fetch_frame = 1;

  public:
    ArducamTOFSensor() = default;
    virtual ~ArducamTOFSensor() = default;

  public:
    /**
     * @brief Open the camera.
     *
     * @param[out] info Camera information.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode open(CameraInfo& info) = 0;

    /**
     * @brief Close camera.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode close() = 0;

    /**
     * @brief Start the camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode start() = 0;

    /**
     * @brief Stop camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode stop() = 0;

    /**
     * @brief Get camera information.
     */
    virtual CameraInfo getCameraInfo() const = 0;

    /**
     * @brief Read frame data from the camera.
     *
     * @param[out] data_ptr  Address of the frame data.
     * @param[out] timestamp The timestamp of the frame.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getFrame(uint8_t* data_ptr, uint64_t& timestamp) = 0;

    /**
     * @brief Switch camera range.
     *
     * @param[in] mode  Mode type.
     * @param[in] value Mode value.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode setControl(CameraCtrl mode, int value) = 0;

    /**
     * @brief get camera parameters.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getControl(CameraCtrl mode, int* value) const = 0;
};

} // namespace Arducam

#endif
