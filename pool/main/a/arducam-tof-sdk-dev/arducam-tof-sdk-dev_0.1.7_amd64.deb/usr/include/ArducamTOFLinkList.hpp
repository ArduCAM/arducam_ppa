#ifndef __TOF_LINKLIST_H
#define __TOF_LINKLIST_H

#include <memory>
#include <mutex>
#include <vector>

#include "ArducamTOFData.hpp"
#include "ArducamTOFUnity.hpp"
namespace Arducam
{
class CacheData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<uint8_t[]> _cacheData;
    FrameDataFormat _dataFormat;

  public:
    CacheData(FrameDataFormat dataFormat);
    void updateTime(uint64_t timestamp);
    void* getData(FrameType type);
    TofErrorCode getFrameDataFormat(FrameType type, FrameDataFormat& format) override;
};

class DepthData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<float[]> _confidenceData;
    std::unique_ptr<float[]> _amplitudeData;
    std::unique_ptr<float[]> _depthData;
    FrameDataFormat _depthFormat;
    FrameDataFormat _amplitudeFormat;

  public:
    DepthData(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat);
    void updateTime(uint64_t timestamp);
    void* getData(FrameType type);
    TofErrorCode getFrameDataFormat(FrameType type, FrameDataFormat& format);
};

class RawData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<int16_t[]> _rawData;
    FrameDataFormat _dataFormat;

  public:
    RawData(FrameDataFormat dataFormat);
    void updateTime(uint64_t timestamp);
    void* getData(FrameType type);
    TofErrorCode getFrameDataFormat(FrameType type, FrameDataFormat& format);
};

class LinkNode
{
  public:
    LinkNode* _next;

  private:
    ArducamFrameBuffer* _data;

  public:
    LinkNode(FrameDataFormat dataFormat, LinkNode* pre, LinkNode* next);
    LinkNode(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat, LinkNode* pre, LinkNode* next);
    ~LinkNode();
    void updateTime(uint64_t timestamp);
    void* getData(FrameType type);
    TofErrorCode getFrameDataFormat(FrameType type, FrameDataFormat& format);
    inline ArducamFrameBuffer* Get()
    {
        return _data;
    };
};

class LinkList
{
  private:
    LinkNode* _cache_list;
    LinkNode* _out_head;
    LinkNode* _out_tail;
    std::vector<LinkNode*> _vec;
    std::mutex _mutex_cache;
    // std::mutex mutex_frame;

  public:
    LinkList(FrameDataFormat dataFormat);
    LinkList(FrameDataFormat dataFormat, int size);
    LinkList(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat);
    LinkList(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat, int size);
    ~LinkList();
    // 入栈
    TofErrorCode cache_Push(LinkNode** node);
    // 出栈
    TofErrorCode cache_Pop(LinkNode** node);
    // 出队
    TofErrorCode DeQueue(LinkNode** node);
    // 入队
    TofErrorCode EnQueue(LinkNode** node);

    TofErrorCode frame_Recycle(ArducamFrameBuffer** node);

  private:
    bool is_element_in_vector(std::vector<LinkNode*> v, LinkNode* element);
    LinkNode* find_in_vector(std::vector<LinkNode*> v, ArducamFrameBuffer* element);
};
} // namespace Arducam
#endif