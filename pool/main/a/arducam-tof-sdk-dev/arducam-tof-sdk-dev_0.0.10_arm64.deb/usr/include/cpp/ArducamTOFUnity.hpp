#ifndef __TOF_UNITY_H
#define __TOF_UNITY_H

#include <string>
#include <vector>
namespace Arducam
{

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#define ARDUCAM_TOF_SENSOR_BUFFER_COUNT 4

#define ARDUCAM_TOF_SENSOR_CACHE_TIMEOUT 5000

#define ARDUCAM_TOF_SENSOR_CACHE_BUFFER_COUNT 8

    const unsigned int sensor_frame_width = 240;

    const unsigned int sensor_frame_height = 180;
#endif
    /**
     * @brief Some types of frame data
     *
     */
    enum class FrameType
    {
        RAW_FRAME = 0,
        AMPLITUDE_FRAME,
        DEPTH_FRAME,
        CACHE_FRAME,
        FRAME_TYPE_COUNT,
    };

    /**
     * @brief Description of frame data format
     *
     */
    struct FrameDataFormat
    {
        unsigned int width;  //! width of frame
        unsigned int height; //! height of frame
        FrameType type;      //! type of frame
        // uint8_t bitdepth;
        uint64_t timestamp;

        bool operator==(const FrameDataFormat &rhs)
        {
            return this->type == rhs.type && this->height == rhs.height && this->width == rhs.width;
        }

        bool operator!=(const FrameDataFormat &rhs)
        {
            return !(*this == rhs);
        }
    };
    
    bool operator==(const FrameDataFormat &lhs, const FrameDataFormat &rhs);

    /**
     * @brief
     *
     */
    enum class Platform
    {
        default_platform = 0,
        Jetson_Nano,
        Jetson_NX,
        Jetson_other,
        Raspberry_Pi
    };

    /**
     * @brief Frame description for the frame data set
     *
     */
    struct FrameFormat
    {
        FrameType type;
        std::vector<FrameDataFormat> formats;
        unsigned int width;
        unsigned int height;

        bool operator==(const FrameFormat &rhs)
        {
            return this->formats == rhs.formats && this->type == rhs.type && this->height == rhs.height && this->width == rhs.width;
        }

        bool operator!=(const FrameFormat &rhs)
        {
            return !(*this == rhs);
        }

        FrameFormat &operator=(const FrameFormat &src)
        {
            if (this == &src)
                return *this;
            this->width = src.width;
            this->height = src.height;
            this->type = src.type;
            this->formats.assign(src.formats.begin(), src.formats.end());
            return *this;
        }
    };

    enum class Connection
    {
        CSI = 0,
        USB,
        CONNECT_COUNT
    };

    /**
     * @struct CameraInfo
     * @brief Basic information of the camera module
     */
    struct CameraInfo
    {
        unsigned int index;
        Connection connect;
        FrameType type;
        unsigned int width;
        unsigned int height;
    };

    enum class ControlID
    {
        RANGE = 0,
        EXPOSURE,
    };

} // namespace Arducam
#endif