#ifndef __TOF_LINKLIST_H
#define __TOF_LINKLIST_H

#include <vector>
#include <mutex>
#include <memory>

#include "ArduCamTOFUnity.hpp"
#include "ArduCamTOFData.hpp"
namespace ArduCam
{
    class CacheData : public AbstractData
    {
        std::unique_ptr<uint8_t[]> cacheData;
        FrameDataFormat m_dataFormat;

    public:
        CacheData(FrameDataFormat dataFormat);
        void *getData(FrameType type);
        int getFrameDataFormat(FrameType type, FrameDataFormat &format);
    };

    class DepthData : public AbstractData
    {
    private:
        std::unique_ptr<float[]> amplitudeData;
        std::unique_ptr<float[]> depthData;
        FrameDataFormat m_depthFormat;
        FrameDataFormat m_amplitudeFormat;

    public:
        DepthData(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat);
        void *getData(FrameType type);
        int getFrameDataFormat(FrameType type, FrameDataFormat &format);
    };

    class RawData : public AbstractData
    {
    private:
        std::unique_ptr<int16_t[]> rawData;
        FrameDataFormat m_dataFormat;

    public:
        RawData(FrameDataFormat dataFormat);
        void *getData(FrameType type);
        int getFrameDataFormat(FrameType type, FrameDataFormat &format);
    };

    class LinkNode
    {
    public:
        // LinkNode *prev;
        LinkNode *next;
    private:
        AbstractData *data;
    
    public:
        LinkNode(FrameDataFormat dataFormat, LinkNode *_pre, LinkNode *_next);
        LinkNode(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat, LinkNode *a_pre, LinkNode *a_next);
        ~LinkNode();
        void *getData(FrameType type);
        int getFrameDataFormat(FrameType type, FrameDataFormat &format);
        inline AbstractData *Get() {return data;};
    };

    class LinkList
    {
    private:
        LinkNode *cache_list;
        LinkNode *out_head;
        LinkNode *out_tail;
        std::vector<LinkNode *> vec;
        std::mutex mutex_cache;
        std::mutex mutex_frame;

    public:
        LinkList(FrameDataFormat dataFormat);
        LinkList(FrameDataFormat dataFormat, int size);
        LinkList(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat);
        LinkList(FrameDataFormat depthFormat, FrameDataFormat amplitudeFormat, int size);
        ~LinkList();
        // 入栈
        int cache_Push(LinkNode **node);
        // 出栈
        int cache_Pop(LinkNode **node);
        // 出队
        int DeQueue(LinkNode **node);
        // 入队
        int EnQueue(LinkNode **node);

        int frame_Recycle(AbstractData **node);
    private:
        bool is_element_in_vector(std::vector<LinkNode *> v, LinkNode *element);
        LinkNode* find_in_vector(std::vector<LinkNode *> v, AbstractData *element);
    };
} // namespace ArduCam
#endif