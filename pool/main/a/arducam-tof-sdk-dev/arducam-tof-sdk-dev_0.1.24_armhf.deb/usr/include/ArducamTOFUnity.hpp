#ifndef __TOF_UNITY_H
#define __TOF_UNITY_H

#include <stdint.h>
#include <vector>

#ifndef DOXYGEN_SHOULD_SKIP_THIS
// clang-format off
#if defined _WIN32 || defined __CYGWIN__
  #ifdef BUILDING_DEPTH_CAMERA_DLL
    #ifdef __GNUC__
      #define DEPTH_CAMERA_PUBLIC __attribute__((dllexport))
    #else
      #define DEPTH_CAMERA_PUBLIC __declspec(dllexport) // Note: actually gcc seems to also supports this syntax.
    #endif
  #elif defined(BUILDING_DEPTH_CAMERA_STATIC)
      #define DEPTH_CAMERA_PUBLIC
  #else
    #ifdef __GNUC__
      #define DEPTH_CAMERA_PUBLIC __attribute__((dllimport))
    #else
      #define DEPTH_CAMERA_PUBLIC __declspec(dllimport) // Note: actually gcc seems to also supports this syntax.
    #endif
  #endif
  #define DEPTH_CAMERA_LOCAL
#else
  #if __GNUC__ >= 4
    #define DEPTH_CAMERA_PUBLIC __attribute__((visibility("default")))
    #define DEPTH_CAMERA_LOCAL  __attribute__((visibility("hidden")))
  #else
    #define DEPTH_CAMERA_PUBLIC
    #define DEPTH_CAMERA_LOCAL
  #endif
#endif
// clang-format on
#endif

namespace Arducam
{

/**
 * @brief Error code
 */
enum TofErrorCode {
    ArducamSuccess = 0,
    ArducamInvalidParameter = 1,
    ArducamNoCache = 2,
    ArducamUnkownDevice = 3,
    ArducamNotImplemented = 4,
    ArducamNoPermission = 5,

    ArducamSkipFrame = 0xF0,

    ArducamSystemError = -2,
    ArducamUnkownError = -1,
};

DEPTH_CAMERA_PUBLIC const char* to_str(TofErrorCode error);

/**
 * @brief camera connection method.
 */
enum class Connection {
    CSI = 0,
    USB,
    CONNECT_COUNT,
};

/**
 * @brief DeviceType
 */
enum DeviceType {
    DEVICE_VGA,
    DEVICE_HQVGA,
};

/**
 * @brief Some types of frame data
 */
enum class FrameType {
    RAW_FRAME = 0,
    CONFIDENCE_FRAME,
    DEPTH_FRAME,
    AMPLITUDE_FRAME,
    CACHE_FRAME,
    FRAME_TYPE_COUNT,
};

/**
 * @brief Camera control type
 */
enum class Control {
    RANGE = 0,
    FMT_WIDTH,
    FMT_HEIGHT,
    MODE,
    FRAME_MODE,
    EXPOSURE,
    FRAME_RATE,
    SKIP_FRAME,
    SKIP_FRAME_LOOP,
    AUTO_FRAME_RATE,
    INTRINSIC_FX, //!< focal length in x direction, the real fx is this value / 100
    INTRINSIC_FY, //!< focal length in y direction, the real fy is this value / 100
    INTRINSIC_CX, //!< principal point in x direction, the real cx is this value / 100
    INTRINSIC_CY, //!< principal point in y direction, the real cy is this value / 100
    DENOISE,      //!< denoise level
    HFLIP,
    VFLIP,
    CONFIG_DIR_EXT = 0x100,
    LOAD_CALI_DATA,
    SAVE_CALI_DATA,
    I2C_BY_PASS,
    I2C_BUS_NUM,
};

enum class TofWorkMode {
    SINGLE_FREQ = 0u, //!< work with single frequency
    DOUBLE_FREQ,
    TRIPLE_FREQ,
    QUAD_FREQ,
    DISTANCE, //!< according to distance measurement parameters to choose parameters
    HDR,      //!< configure chip to measure very near or far object (useful for AE)
    AE,
    BG_OUTDOOR, //!< configure chip to measure background IR radiation (no light from vcsel during phase frame)
    GRAY_ONLY,
    CUSTOM1, //!< for hw-cstar project
    CUSTOM2,
    CUSTOM3,
};

enum class TofFrameWorkMode {
    SINGLE_FREQ_2PHASE = 0u,
    SINGLE_FREQ_4PHASE,
    SINGLE_FREQ_4PHASE_GRAY,            //!< whole frame: 4phase+gray
    SINGLE_FREQ_4PHASE_BG,              //!< whole frame: 4phase+bg
    SINGLE_FREQ_4PHASE_4BG,             //!< whole frame: 4phase+4bg
    SINGLE_FREQ_4PHASE_GRAY_5BG,        //!< whole frame: 4phase+gray+5bg
    SINGLE_FREQ_GRAY_BG_4PHASE_GRAY_BG, // add for hw-cstar project
    SINGLE_FREQ_GRAY_BG_4PHASE_BG,      // add for hw-cstar-v2 project
    SINGLE_FREQ_BG_GRAY_BG_4PHASE,      // add for hw-cstar-v2 project
    SINGLE_FREQ_BG_4PHASE_BG_GRAY,      // add for hw-cstar-v2 project

    DOUBLE_FREQ_4PHASE,                //!< each frequency has 4phase, whole frame: 4phase+4phase
    DOUBLE_FREQ_4PHASE_GRAY_4PHASE_BG, //!< whole frame: (4phase+gray)+(4phase+bg)
    DOUBLE_FREQ_4PHASE_4BG,            //!< whole frame: (4phase+4bg)+(4phase+4bg)
    DOUBLE_FREQ_4PHASE_GRAY_5BG,       //!< whole frame: (4phase+gray+5bg)+(4phase+gray+5bg)

    TRIPLE_FREQ_4PHASE,                            //!< whole frame: (4phase)+(4phase)+(4phase)
    TRIPLE_FREQ_4PHASE_GRAY_4PHASE_GRAY_4PHASE_BG, //!< whole frame: (4phase+gray)+(4phase+gray)+(4phase+bg)

    QUAD_FREQ_4PHASE, //!< whole frame: (4phase)+(4phase)+(4phase)+(4phase)
    QUAD_FREQ_4PHASE_GRAY_4PHASE_BG_4PHASE_GRAY_4PHASE_BG,

    BG_OUTDOOR,
    GRAY_ONLY,
    CUSTOM,
};

/**
 * @brief Platform type
 */
enum class Platform {
    Default = 0,
    Windows,
    Jetson_Nano,
    Jetson_NX,
    Jetson_Orin,
    Jetson_Other,
    Raspberry_Pi,
    Raspberry_Pi5,
    Rockchip,
};

/**
 * @brief Description of frame data format
 */
struct DEPTH_CAMERA_PUBLIC FrameFormat {
    //! width of frame
    unsigned int width;
    //! height of frame
    unsigned int height;
    //! type of frame
    FrameType type;
    //! type of frame
    uint64_t timestamp;

    bool operator==(const FrameFormat& rhs) const
    {
        return this->type == rhs.type && this->height == rhs.height && this->width == rhs.width;
    }

    bool operator!=(const FrameFormat& rhs) const
    {
        return !(*this == rhs);
    }
};

/**
 * @brief Basic information of the camera module
 */
struct DEPTH_CAMERA_PUBLIC CameraInfo {
    unsigned int index;
    Connection connect;
    DeviceType device_type;
    FrameType type;
    unsigned int width;
    unsigned int height;
    unsigned int bit_width;
    unsigned int bpp; // bytes per pixel
};

static inline constexpr int to_int(TofWorkMode mode)
{
    return static_cast<int>(mode);
}

static inline constexpr int to_int(TofFrameWorkMode mode)
{
    return static_cast<int>(mode);
}

} // namespace Arducam
#endif