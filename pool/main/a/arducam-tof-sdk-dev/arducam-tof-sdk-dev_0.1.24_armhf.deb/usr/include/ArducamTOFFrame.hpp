#ifndef __TOF_FRAME_H
#define __TOF_FRAME_H

#include "ArducamTOFLinkList.hpp"
#include "ArducamTOFUnity.hpp"
#include "Semaphore.hpp"

namespace Arducam
{
// typedef LinkNode ArducamFrameBuffer;
// typedef ArducamFrameBuffer ArducamFrameBuffer;

/**
 * @brief Memory space management for saving frame formats and frames
 *
 */
class ArducamTOFFrame
{
#ifndef DOXYGEN_SHOULD_SKIP_THIS

  private:
    FrameFormat _infos;
    std::unique_ptr<LinkList> _implData;
    std::unique_ptr<CacheData> _cache;
    const uint8_t _frame_size;
    Semaphore _sem;

#endif

  public:
    /**
     * @brief Construct a frame instance according to the frame format data and apply for memory space.
     */
    ArducamTOFFrame(const CameraInfo&, const FrameFormat&);
    ~ArducamTOFFrame() = default;

#ifndef DOXYGEN_SHOULD_SKIP_THIS
    /**
     * @brief deep copy
     */
    ArducamTOFFrame(const ArducamTOFFrame&) = delete;
    /**
     * @brief deep copy
     *
     * @param a_fm ArducamTOFFrame class instance.
     */
    ArducamTOFFrame(const std::shared_ptr<ArducamTOFFrame> a_fm) = delete;
#endif

  public:
    /**
     * @brief refer to FrameFormat @ref details,Resetting the frame format and requesting frame memory space.
     *
     * @param[in] details Frame format description structure, including width, height, frameType and bitDepth.
     */
    void setFrameInfo(const FrameFormat& details)
    {
        _infos = details;
    }
    /**
     * @brief Get all frame data formats of the current frame.
     *
     * @return all frame data formats within the frame, If the output type is DEPTH_FRAME, it includes
     *   DEPTH_FRAME and CONFIDENCE_FRAME, if it is RAW_FRAME, only RAW_FRAME.
     */
    FrameFormat frameInfo() const
    {
        return _infos;
    }
    /**
     * @brief Specify the frame data type to get the frame data format.
     *
     * @param type Specify the frame data type.
     *   This parameter can be one of the following values:
     *     @arg RAW_FRAME
     *     @arg CONFIDENCE_FRAME
     *     @arg DEPTH_FRAME
     * @param format Returns the frame data format of the specified frame type
     * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
     */
    // int getFormat(const FrameType &type, FrameFormat &format) const;

    /**
     * @brief Get the Pointer of Frame Data.
     *
     * @param type Specify the frame data type.
     *   This parameter can be one of the following values:
     *     @arg RAW_FRAME
     *     @arg CONFIDENCE_FRAME
     *     @arg DEPTH_FRAME
     * @return Return Pointer of Frame Data.The returned pointer type can be one of the following type:
     *   - int16_t* : RAW_FRAME
     *   - float*   : DEPTH_FRAME
     *   - float*   : CONFIDENCE_FRAME
     */
    CacheData* getCacheData();

    LinkNode* getFrameCache();

    ArducamFrameBuffer* requestFrame(int16_t timeout);

    TofErrorCode refrashFrame(LinkNode* node);

    TofErrorCode realseFrame(ArducamFrameBuffer* node);
};
} // namespace Arducam

#endif
