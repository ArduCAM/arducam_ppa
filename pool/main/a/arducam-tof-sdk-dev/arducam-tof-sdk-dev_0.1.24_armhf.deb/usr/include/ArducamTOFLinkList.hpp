#ifndef __TOF_LINKLIST_H
#define __TOF_LINKLIST_H

#include <cstdio>
#include <memory>
#include <mutex>
#include <vector>

#include "ArducamTOFData.hpp"
#include "ArducamTOFUnity.hpp"
namespace Arducam
{
template<typename T>
class ArrayDeleter
{
  public:
    void operator()(T* ptr)
    {
      delete[] ptr;
    }
};
template<typename T>
class NoDeleter
{
  public:
    void operator()(T*) {}
};

class CacheData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<uint8_t[], NoDeleter<uint8_t>> _cacheData;
    FrameFormat _dataFormat;

  public:
    CacheData(FrameFormat dataFormat);
    void updateTime(uint64_t timestamp) override;
    void* getData(FrameType type) override;
    TofErrorCode getFormat(FrameType type, FrameFormat& format) override;
};

class DepthData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<float[], ArrayDeleter<float>> _confidenceData;
    std::unique_ptr<float[], ArrayDeleter<float>> _amplitudeData;
    std::unique_ptr<float[], ArrayDeleter<float>> _depthData;
    FrameFormat _depthFormat;
    FrameFormat _amplitudeFormat;

  public:
    DepthData(FrameFormat depthFormat, FrameFormat amplitudeFormat);
    void updateTime(uint64_t timestamp) override;
    void* getData(FrameType type) override;
    TofErrorCode getFormat(FrameType type, FrameFormat& format) override;
};

class RawData : public ArducamFrameBuffer
{
  private:
    std::unique_ptr<int16_t[], ArrayDeleter<int16_t>> _rawData;
    FrameFormat _dataFormat;

  public:
    RawData(FrameFormat dataFormat);
    void updateTime(uint64_t timestamp) override;
    void* getData(FrameType type) override;
    TofErrorCode getFormat(FrameType type, FrameFormat& format) override;
};

class LinkNode
{
  public:
    LinkNode* _next;

  private:
    ArducamFrameBuffer* _data;

  public:
    LinkNode(FrameFormat dataFormat, LinkNode* pre, LinkNode* next);
    LinkNode(FrameFormat depthFormat, FrameFormat amplitudeFormat, LinkNode* pre, LinkNode* next);
    ~LinkNode();
    void updateTime(uint64_t timestamp);
    void* getData(FrameType type);
    TofErrorCode getFormat(FrameType type, FrameFormat& format);
    inline ArducamFrameBuffer* Get()
    {
        return _data;
    };
};

class LinkList
{
  private:
    LinkNode* _cache_list;
    LinkNode* _out_head;
    LinkNode* _out_tail;
    std::vector<LinkNode*> _vec;
    std::mutex _mutex_cache;
    // std::mutex mutex_frame;

  public:
    LinkList(FrameFormat dataFormat);
    LinkList(FrameFormat dataFormat, int size);
    LinkList(FrameFormat depthFormat, FrameFormat amplitudeFormat);
    LinkList(FrameFormat depthFormat, FrameFormat amplitudeFormat, int size);
    ~LinkList();
    // 入栈
    TofErrorCode cache_Push(LinkNode** node);
    // 出栈
    TofErrorCode cache_Pop(LinkNode** node);
    // 出队
    TofErrorCode DeQueue(LinkNode** node);
    // 入队
    TofErrorCode EnQueue(LinkNode** node);

    TofErrorCode frame_Recycle(ArducamFrameBuffer** node);

  private:
    bool is_element_in_vector(std::vector<LinkNode*> v, LinkNode* element);
    LinkNode* find_in_vector(std::vector<LinkNode*> v, ArducamFrameBuffer* element);
};
} // namespace Arducam
#endif