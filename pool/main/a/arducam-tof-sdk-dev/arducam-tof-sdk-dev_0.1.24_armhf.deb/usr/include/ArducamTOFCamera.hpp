#ifndef __TOF_CAMERA_H
#define __TOF_CAMERA_H

#include <atomic>
#include <cmath>
#include <functional>
#include <chrono>
#include <thread>

#include "ArducamDevice.hpp"
#include "ArducamTOFFrame.hpp"
#include "ArducamTOFSensor.hpp"
#include "ArducamTOFUnity.hpp"

namespace Arducam
{

#ifndef DOXYGEN_SHOULD_SKIP_THIS
// typedef std::function<void(std::string frame_type, void *frame_ptr)> DoneCallback;
#endif /* DOXYGEN_SHOULD_SKIP_THIS */

/**
 * @brief Camera application layer class, used to manage the camera and process frame data
 */
class ArducamTOFCamera
{
  public:
    /**
     * @brief Initialize the camera configuration and turn on the camera,
     *   set the initialization frame according to the `mode`
     *
     * @param[in] mode Specify the connection method.
     * @param[in] index Device node, the default value is video0.
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode open(Connection mode, const int index = 0);

    /**
     * @brief Initialize the camera configuration and turn on the camera,
     *   set the initialization frame according to the `path`
     *
     * @param[in] path Specify the camera configuration file path.
     * @param[in] index Device node, the default value is video0.
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode openWithFile(const char* path, const int index = 0);

    /**
     * @brief close the camera
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode close();

    /**
     * @brief Start the camera stream and start processing.
     *
     * @param type Specify the camera output format.
     *      This parameter can be one of the following values:
     *          @arg RAW_FRAME
     *          @arg DEPTH_FRAME
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode start(FrameType type = FrameType::DEPTH_FRAME);

    /**
     * @brief Stop camera stream and processing.
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode stop();

    /**
     * @brief Set camera parameters
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode setControl(Control mode, int value);

    /**
     * @brief Set camera parameters
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode setControlExt(Control mode, const char* value);

    /**
     * @brief Get camera parameters
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode getControl(Control mode, int* value);

    /**
     * @brief Get camera parameters
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode getControlExt(Control mode, const char** value);

    /**
     * @brief Write Sensor Register
     *
     * @return An ErrorCode.
     */
    TofErrorCode writeSensor(uint32_t addr, uint32_t val);

    /**
     * @brief Read Sensor Register
     *
     * @return An ErrorCode.
     */
    TofErrorCode readSensor(uint32_t addr, uint32_t& val);

    /**
     * @brief Get the Camera frames format.
     *
     * @return All frame data formats contained in frame, The returned value include: width, height and Frametype
     */
    DEPTH_CAMERA_PUBLIC CameraInfo getCameraInfo() const;

    /**
     * @brief Get the Camera ID.
     *
     * @return The camera ID. empty string if not supported.
     * @note Call this function after the camera is started.
     */
    DEPTH_CAMERA_PUBLIC const char* getCameraID() const;

    /**
     * @brief Request a frame of data from the frame processing thread
     *
     * @param timeout Timeout time, -1 if wait indefinitely, 0 if immediate,
     *   other values indicate the maximum waiting time, in milliseconds.
     * @return ArducamTOFFrame class address.
     */
    DEPTH_CAMERA_PUBLIC ArducamFrameBuffer* requestFrame(int16_t timeout);

    /**
     * @brief Free the memory space of the frame
     *
     * @param frame The address of the frame to be released
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode releaseFrame(ArducamFrameBuffer* frame);
#ifndef DOXYGEN_SHOULD_SKIP_THIS

    DEPTH_CAMERA_PUBLIC TofErrorCode openPostHandle();

  private:
    CameraInfo _info;

    FrameFormat _raw_info, _depth_info;

    std::unique_ptr<ArducamTOFSensor> _depthSensor;

    std::unique_ptr<ArducamDevice> _depthDevice;

    std::unique_ptr<ArducamTOFFrame> _frame;

    std::thread _capture_thread;

    volatile std::atomic<bool> _capture_thread_abort;

    Platform _platform;

    int _skip_frame, _loop_frame, _frame_count;
    float _avg_duration = 0, _alpha = 1.F / 10, _avg_fps = 0;
    int _fps_count = 0;
    std::chrono::high_resolution_clock::time_point _start_time;
    bool _auto_fps = true;

  private:
    DEPTH_CAMERA_PUBLIC void getRawImages(uint8_t* cache_ptr, int16_t* raw_ptr);
    DEPTH_CAMERA_PUBLIC bool getPhaseImage(uint8_t* cache_ptr, float* phase_ptr, float* amplitude, float* confidence);

    DEPTH_CAMERA_PUBLIC TofErrorCode analysisFrame(uint8_t* cache_ptr, LinkNode* frame);

    DEPTH_CAMERA_PUBLIC void captureThread();

    DEPTH_CAMERA_PUBLIC void updateFps();

    DEPTH_CAMERA_PUBLIC void adjustFrameRate();

    /**
     * @brief  Specifies the frame Output Type
     * @note Please call the function operation to reset the frame output format before starting the camera
     *
     * @param type Specify the camera output format.
     *   This parameter can be one of the following values:
     *     @arg RAW_FRAME
     *     @arg DEPTH_FRAME
     *
     * @return An ErrorCode.
     */
    DEPTH_CAMERA_PUBLIC TofErrorCode setOutputType(FrameType type);

  public:
    DEPTH_CAMERA_PUBLIC ArducamTOFCamera();

    DEPTH_CAMERA_PUBLIC ~ArducamTOFCamera();
#endif
};
} // namespace Arducam
#endif
