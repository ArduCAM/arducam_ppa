#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ArducamDepthCamera::ArducamDepthCamera4C" for configuration "Release"
set_property(TARGET ArducamDepthCamera::ArducamDepthCamera4C APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ArducamDepthCamera::ArducamDepthCamera4C PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM_NASM;C"
  # IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libArducamDepthCamera4C.so"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libArducamDepthCamera4C.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS ArducamDepthCamera::ArducamDepthCamera4C )
list(APPEND _IMPORT_CHECK_FILES_FOR_ArducamDepthCamera::ArducamDepthCamera4C "${_IMPORT_PREFIX}/lib/libArducamDepthCamera4C.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
