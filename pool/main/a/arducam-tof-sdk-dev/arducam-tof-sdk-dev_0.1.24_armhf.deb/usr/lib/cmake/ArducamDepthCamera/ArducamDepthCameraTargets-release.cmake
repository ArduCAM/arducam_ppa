#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ArducamDepthCamera::ArducamDepthCamera" for configuration "Release"
set_property(TARGET ArducamDepthCamera::ArducamDepthCamera APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ArducamDepthCamera::ArducamDepthCamera PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM_NASM;C"
  # IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libArducamDepthCamera.so"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libArducamDepthCamera.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS ArducamDepthCamera::ArducamDepthCamera )
list(APPEND _IMPORT_CHECK_FILES_FOR_ArducamDepthCamera::ArducamDepthCamera "${_IMPORT_PREFIX}/lib/libArducamDepthCamera.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
