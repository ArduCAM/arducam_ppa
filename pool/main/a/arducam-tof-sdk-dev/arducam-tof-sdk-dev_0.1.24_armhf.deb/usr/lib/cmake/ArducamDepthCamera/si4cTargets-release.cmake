#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "ArducamDepthCamera::si4c" for configuration "Release"
set_property(TARGET ArducamDepthCamera::si4c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(ArducamDepthCamera::si4c PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "ASM_NASM;C"
  # IMPORTED_IMPLIB_RELEASE "${_IMPORT_PREFIX}/lib/libsi4c.so"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsi4c.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS ArducamDepthCamera::si4c )
list(APPEND _IMPORT_CHECK_FILES_FOR_ArducamDepthCamera::si4c "${_IMPORT_PREFIX}/lib/libsi4c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
