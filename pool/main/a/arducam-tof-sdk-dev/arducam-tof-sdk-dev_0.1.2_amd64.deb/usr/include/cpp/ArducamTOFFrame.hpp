#ifndef __TOF_FRAME_H
#define __TOF_FRAME_H

#include "ArducamTOFLinkList.hpp"
#include "ArducamTOFUnity.hpp"
#include "Semaphore.hpp"

namespace Arducam
{
// typedef LinkNode ArducamFrameBuffer;
// typedef ArducamFrameBuffer ArducamFrameBuffer;

/**
 * @brief Memory space management for saving frame formats and frames
 *
 */
class ArducamTOFFrame
{
#ifndef DOXYGEN_SHOULD_SKIP_THIS
  private:
    FrameFormat _Infos;
    std::unique_ptr<LinkList> _implData;
    std::unique_ptr<CacheData> _cache;
    const uint8_t _frame_size;
    Semaphore _sem;
#endif
  public:
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    // private:
    //     void allocFrameData(const FrameFormat &details);

  public:
    // ArducamTOFFrame();
#endif
    /**
     * @brief Construct a frame instance according to the frame format data and apply for memory space.
     *
     */
    ArducamTOFFrame(const FrameFormat&);
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    ~ArducamTOFFrame();
    /**
     * @brief deep copy
     *
     */
    ArducamTOFFrame(const ArducamTOFFrame&);
#endif
    /**
     * @brief deep copy
     *
     * @param a_fm ArducamTOFFrame class instance.
     */
    ArducamTOFFrame(const std::shared_ptr<ArducamTOFFrame> a_fm);

    // ArducamTOFFrame &operator=(const ArducamTOFFrame &);

  public:
    /**
     * @brief refer to @ref FrameFormat,Resetting the frame format and requesting frame memory space.
     *
     * @param details Frame format description structure, including width, height, frameType and bitDepth.
     * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
     */
    int setFrameInfo(const FrameFormat& details);
    /**
     * @brief Get all frame data formats of the current frame.
     *
     * @param details Returns all frame data formats within the frame,If the output type is DEPTH_FRAME, it includes
     * DEPTH_FRAME and AMPLITUDE_FRAME, if it is RAW_FRAME, only RAW_FRAME.
     * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
     */
    int getFrameFormat(FrameFormat& details) const;
    /**
     * @brief Specify the frame data type to get the frame data format.
     *
     * @param type Specify the frame data type.
     *      This parameter can be one of the following values:
     *          @arg RAW_FRAME
     *          @arg AMPLITUDE_FRAME
     *          @arg DEPTH_FRAME
     * @param format Returns the frame data format of the specified frame type
     * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
     */
    // int getFrameDataFormat(const FrameType &type, FrameDataFormat &format) const;
    /**
     * @brief Get the Pointer of Frame Data.
     *
     * @param type  Specify the frame data type.
     *      This parameter can be one of the following values:
     *          @arg RAW_FRAME
     *          @arg AMPLITUDE_FRAME
     *          @arg DEPTH_FRAME
     * @return Return Pointer of Frame Data.The returned pointer type can be one of the following type:
     *          - int16_t* : RAW_FRAME
     *          - float*   : DEPTH_FRAME
     *          - float*   : AMPLITUDE_FRAME
     */

    CacheData* getCacheData();

    LinkNode* getFrameCache();

    int refrashFrame(LinkNode* node);

    ArducamFrameBuffer* requestFrame(int16_t timeout);

    int realseFrame(ArducamFrameBuffer* node);

  public:
    /**
     * @brief Get camera output type.
     *
     * @return FrameType:RAW_FRAME,DEPTH_FRAME.
     */
    // inline FrameType getOutputType()
    // {
    //     return _Infos.type;
    // }
};
} // namespace Arducam

#endif
