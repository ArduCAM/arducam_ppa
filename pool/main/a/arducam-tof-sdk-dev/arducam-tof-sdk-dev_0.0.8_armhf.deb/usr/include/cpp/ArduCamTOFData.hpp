#pragma once
#include "ArduCamTOFUnity.hpp"
namespace ArduCam
{
    class AbstractData
    {
    public:
        AbstractData() = default;
        virtual void *getData(FrameType type) = 0;
        virtual int getFrameDataFormat(FrameType type, FrameDataFormat &format) = 0;
        virtual ~AbstractData() = default;
    };
}
