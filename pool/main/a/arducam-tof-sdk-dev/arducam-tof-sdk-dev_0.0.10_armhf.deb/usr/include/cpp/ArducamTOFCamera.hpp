#ifndef __TOF_CAMERA_H
#define __TOF_CAMERA_H

#include <functional>
#include <cmath>
#include <thread>

#include "ArducamTOFSensor.hpp"
#include "ArducamTOFFrame.hpp"
#include "ArducamTOFUnity.hpp"

namespace Arducam
{
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    /**
     * @brief
     *
     */
    // typedef std::function<void(std::string frame_type, void *frame_ptr)> DoneCallback;
#endif /* DOXYGEN_SHOULD_SKIP_THIS */
    /**
     * @brief Camera application layer class, used to manage the camera and process frame data
     *
     */
    class ArducamTOFCamera
    {
    public:
        /**
         * @brief Initialize the camera configuration and turn on the camera, set the initialization frame according to the @ref mode
         *
         * @param mode Specify the connection method.
         *      This parameter can be one of the following values:
         *          @arg CSI
         *          @arg USB
         * @param path Device node, the default value is video0.
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int init(Connection mode, const int index = 0);

        /**
         * @brief Start the camera stream and start processing.
         *
         * @param type Specify the camera output format.
         *      This parameter can be one of the following values:
         *          @arg RAW_FRAME
         *          @arg DEPTH_FRAME
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int start(FrameType type = FrameType::DEPTH_FRAME);
        /**
         * @brief Stop camera stream and processing.
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int stop();
        /**
         * @brief  Specifies the frame Output Type
         * @note Please call the function operation to reset the frame output format before starting the camera
         *
         * @param type Specify the camera output format.
         *      This parameter can be one of the following values:
         *          @arg RAW_FRAME
         *          @arg DEPTH_FRAME
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int setOutputType(FrameType type);

        /**
         * @brief Set camera parameters
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int setControl(ControlID mode, int value);

        /**
         * @brief Get the Camera frames format.
         *
         * @return All frame data formats contained in frame, The returned value include: width, height and Frametype
         */
        CameraInfo getCameraInfo() const;

        /**
         * @brief Request a frame of data from the frame processing thread
         *
         * @param timeout Timeout time, -1 means to wait all the time, 0 means immediate range, other values indicate the maximum waiting time, the unit is milliseconds.
         * @return ArducamTOFFrame class address.
         */
        ArducamFrameBuffer *requestFrame(int16_t timeout);

        /**
         * @brief Free the memory space of the frame
         *
         * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
         */
        int releaseFrame(ArducamFrameBuffer *frame);
#ifndef DOXYGEN_SHOULD_SKIP_THIS

        int initFromFile(const char *path, float _f_mod, const int index = 0);

    private:
        CameraInfo m_Info;

        std::unique_ptr<ArducamTOFSensor> m_depthSensor;

        std::unique_ptr<ArducamTOFFrame> m_frame;

        std::thread capture_thread_;

        bool capture_thread_abort_;

        Platform _hw_model;

        uint8_t shift_num;

        float f_mod = 375e5; //! Camera light wave modulation frequency

        const float c = 3e8; //! speed of light

        const float pi = M_PI; //! π

        const unsigned int image_size = 43200;

    private:
        void getPhaseAndAmplitudeImage(uint8_t *cache_ptr, float *phase_ptr, float *amplitude_ptr);

        void getPhaseAndAmplitudeImage(int16_t *raw_ptr, float *phase_ptr, float *amplitude_ptr);

        void getRawImages(uint8_t *cache_ptr, int16_t *raw_ptr);

        int analysisFrame(uint8_t *cache_ptr, LinkNode *frame);

        void captureThread();

    public:
        ArducamTOFCamera();

        ~ArducamTOFCamera();
#endif
    };
} // namespace Arducam
#endif