#ifndef __SEMAPHORE_H
#define __SEMAPHORE_H

#include <mutex>
#include <condition_variable>
#include <cstdint>

class Semaphore
{
public:
    explicit Semaphore(int max_count = 3) : count_(0), max_count_(max_count) {}

    void Signal()
    {
        std::unique_lock<std::mutex> lock(mutex_);

        if (count_ <= max_count_)
        {
            ++count_;
            cv_.notify_all();
        }
    }
    bool Wait(int16_t ms = 20)
    {
        std::unique_lock<std::mutex> lock(mutex_);

        while (count_ == 0)
        {
            if (ms < 0)
            {
                cv_.wait(lock, [=]
                         { return count_ > 0; });
            }
            else
            {
                if (cv_.wait_for(lock, std::chrono::milliseconds(ms), [=]
                                 { return count_ > 0; }) == false)
                    return false;
            }
        }
        --count_;
        return true;
    }

    void cleanup()
    {
        std::unique_lock<std::mutex> lock(mutex_);
        count_ = 0;
    }

private:
    std::mutex mutex_;
    std::condition_variable cv_;
    volatile int count_;
    const int max_count_;
};
#endif