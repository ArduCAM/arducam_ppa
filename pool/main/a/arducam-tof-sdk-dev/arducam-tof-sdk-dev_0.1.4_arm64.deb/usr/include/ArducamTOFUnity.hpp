#ifndef __TOF_UNITY_H
#define __TOF_UNITY_H

#include <stdint.h>
#include <vector>

namespace Arducam
{

/**
 * @brief Error code
 */
enum TofErrorCode {
    ArducamSucess = 0,
    ArducamInvalidParameter = 1,
    ArducamNoCache = 2,
    ArducamUnkownDevice = 3,
    ArducamNotImplemented = 4,

    ArducamSkipFrame = 0xF0,

    ArducamSystemError = -2,
    ArducamUnkownError = -1,
};

const char* to_str(TofErrorCode error);

/**
 * @brief DeviceType
 */
enum DeviceType {
    DEVICE_VGA,
    DEVICE_HQVGA,
};

/**
 * @brief Some types of frame data
 */
enum class FrameType {
    RAW_FRAME = 0,
    CONFIDENCE_FRAME,
    DEPTH_FRAME,
    CACHE_FRAME,
    FRAME_TYPE_COUNT,
};

/**
 * @brief Description of frame data format
 */
struct FrameDataFormat {
    //! width of frame
    unsigned int width;
    //! height of frame
    unsigned int height;
    //! type of frame
    FrameType type;
    //! type of frame
    uint64_t timestamp;

    bool operator==(const FrameDataFormat& rhs) const
    {
        return this->type == rhs.type && this->height == rhs.height && this->width == rhs.width;
    }

    bool operator!=(const FrameDataFormat& rhs) const
    {
        return !(*this == rhs);
    }
};

/**
 * @brief Platform type
 */
enum class Platform {
    default_platform = 0,
    Windows,
    Jetson_Nano,
    Jetson_NX,
    Jetson_other,
    Raspberry_Pi,
    Raspberry_Pi5,
};

/**
 * @brief Frame description for the frame data set
 */
struct FrameFormat {
    FrameType type;
    std::vector<FrameDataFormat> formats;
    unsigned int width;
    unsigned int height;

    bool operator==(const FrameFormat& rhs) const
    {
        return this->type == rhs.type && this->height == rhs.height && this->width == rhs.width &&
               this->formats == rhs.formats;
    }

    bool operator!=(const FrameFormat& rhs) const
    {
        return !(*this == rhs);
    }

    FrameFormat& operator=(const FrameFormat& src) = default;
};

/**
 * @brief camera connection method.
 */
enum class Connection {
    CSI = 0,
    USB,
    CONNECT_COUNT,
};

/**
 * @brief Basic information of the camera module
 */
struct CameraInfo {
    unsigned int index;
    Connection connect;
    DeviceType device_type;
    FrameType type;
    unsigned int width;
    unsigned int height;
    unsigned int bit_width;
    unsigned int bpp; // bytes per pixel
};

enum class TofWorkMode {
    SINGLE_FREQ = 0u, //!< work with single frequency
    DOUBLE_FREQ,
    TRIPLE_FREQ,
    QUAD_FREQ,
    DISTANCE, //!< according to distance measurement parameters to choose parameters
    HDR,      //!< configure chip to measure very near or far object (useful for AE)
    AE,
    BG_OUTDOOR, //!< configure chip to measure background IR radiation (no light from vcsel during phase frame)
    GRAY_ONLY,
    CUSTOM1, //!< for hw-cstar project
    CUSTOM2,
    CUSTOM3,
};

enum class TofFrameWorkMode {
    SINGLE_FREQ_2PHASE = 0u,
    SINGLE_FREQ_4PHASE,
    SINGLE_FREQ_4PHASE_GRAY,            //!< whole frame: 4phase+gray
    SINGLE_FREQ_4PHASE_BG,              //!< whole frame: 4phase+bg
    SINGLE_FREQ_4PHASE_4BG,             //!< whole frame: 4phase+4bg
    SINGLE_FREQ_4PHASE_GRAY_5BG,        //!< whole frame: 4phase+gray+5bg
    SINGLE_FREQ_GRAY_BG_4PHASE_GRAY_BG, // add for hw-cstar project
    SINGLE_FREQ_GRAY_BG_4PHASE_BG,      // add for hw-cstar-v2 project
    SINGLE_FREQ_BG_GRAY_BG_4PHASE,      // add for hw-cstar-v2 project
    SINGLE_FREQ_BG_4PHASE_BG_GRAY,      // add for hw-cstar-v2 project

    DOUBLE_FREQ_4PHASE,                //!< each frequency has 4phase, whole frame: 4phase+4phase
    DOUBLE_FREQ_4PHASE_GRAY_4PHASE_BG, //!< whole frame: (4phase+gray)+(4phase+bg)
    DOUBLE_FREQ_4PHASE_4BG,            //!< whole frame: (4phase+4bg)+(4phase+4bg)
    DOUBLE_FREQ_4PHASE_GRAY_5BG,       //!< whole frame: (4phase+gray+5bg)+(4phase+gray+5bg)

    TRIPLE_FREQ_4PHASE,                            //!< whole frame: (4phase)+(4phase)+(4phase)
    TRIPLE_FREQ_4PHASE_GRAY_4PHASE_GRAY_4PHASE_BG, //!< whole frame: (4phase+gray)+(4phase+gray)+(4phase+bg)

    QUAD_FREQ_4PHASE, //!< whole frame: (4phase)+(4phase)+(4phase)+(4phase)
    QUAD_FREQ_4PHASE_GRAY_4PHASE_BG_4PHASE_GRAY_4PHASE_BG,

    BG_OUTDOOR,
    GRAY_ONLY,
    CUSTOM,
};

static inline constexpr int to_int(TofWorkMode mode)
{
    return static_cast<int>(mode);
}

static inline constexpr int to_int(TofFrameWorkMode mode)
{
    return static_cast<int>(mode);
}

/**
 * @brief Camera control type
 */
enum class CameraCtrl {
    RANGE = 0, /**< only support 4m and 2m range mode */
    FMT_WIDTH,
    FMT_HEIGHT,
    MODE = 0x10,
    FRAME_MODE,
    EXPOSURE = 0x20,
    FRAME_RATE,
    SKIP_FRAME = 0x70,
    SKIP_FRAME_LOOP,
};

} // namespace Arducam
#endif