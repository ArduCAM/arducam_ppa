#pragma once
#include "ArducamTOFUnity.hpp"
namespace Arducam
{

/// @brief AbstractData
class ArducamFrameBuffer
{
  public:
#ifndef DOXYGEN_SHOULD_SKIP_THIS
    ArducamFrameBuffer() = default;
    virtual ~ArducamFrameBuffer() = default;

    virtual void updateTime(uint64_t timestamp) = 0;
#endif
    /**
     * @brief Get the Pointer of Frame Data.
     *
     * @param type  Specify the frame data type.
     *      This parameter can be one of the following values:
     *          @arg RAW_FRAME
     *          @arg AMPLITUDE_FRAME
     *          @arg DEPTH_FRAME
     * @return Return Pointer of Frame Data.The returned pointer type can be one of the following type:
     *          - int16_t* : RAW_FRAME
     *          - float*   : DEPTH_FRAME
     *          - float*   : AMPLITUDE_FRAME
     */
    virtual void* getData(FrameType type) = 0;
    /**
     * @brief Specify the frame data type to get the frame data format.
     *
     * @param type Specify the frame data type.
     *      This parameter can be one of the following values:
     *          @arg RAW_FRAME
     *          @arg AMPLITUDE_FRAME
     *          @arg DEPTH_FRAME
     * @param format Returns the frame data format of the specified frame type
     * @return Return Status code, The returned value can be: OK or ERROR(0 or -1).
     */
    virtual int getFrameDataFormat(FrameType type, FrameDataFormat& format) = 0;
};
} // namespace Arducam
