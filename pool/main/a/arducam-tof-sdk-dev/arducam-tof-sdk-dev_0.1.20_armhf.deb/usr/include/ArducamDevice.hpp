#ifndef __TOF_DEVICE_H
#define __TOF_DEVICE_H

#include "ArducamTOFUnity.hpp"

#include <stdint.h>

namespace Arducam
{
class ArducamTOFSensor;

class ArducamDevice
{
    const Arducam::Platform _platform;

  public:
    ArducamDevice() = default;
    ArducamDevice(Arducam::Platform platform) : _platform(platform) {}
    ArducamDevice(const ArducamDevice&) = delete;
    ArducamDevice& operator=(const ArducamDevice&) = delete;
    ArducamDevice(ArducamDevice&&) = default;
    ArducamDevice& operator=(ArducamDevice&&) = default;
    virtual ~ArducamDevice() = default;

    virtual DeviceType name() const = 0;
    virtual void setInfo(FrameFormat& raw, FrameFormat& depth) const = 0;
    /**
     * @brief open camera.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode open(ArducamTOFSensor* sensor) = 0;
    /**
     * @brief Close camera.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode close() = 0;
    /**
     * @brief Start the camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode start() = 0;
    /**
     * @brief Started the camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode started()
    {
        return TofErrorCode::ArducamSuccess;
    }
    /**
     * @brief Stop camera stream.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode stop() = 0;

    /**
     * @brief Check the endianness of the device.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode setControl(Control mode, int value) = 0;
    /**
     * @brief Set camera parameters
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode setControlExt(Control mode, const char* value) = 0;
    /**
     * @brief Check the endianness of the device.
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getControl(Control mode, int* value) = 0;
    /**
     * @brief Get camera parameters
     *
     * @return An ErrorCode.
     */
    virtual TofErrorCode getControlExt(Control mode, const char** value) = 0;

    /**
     * @brief Get the raw image data.
     *
     * @param[in]  data  image data(cache data).
     * @param[out] dest  raw image data.
     */
    virtual bool getRawImages(uint8_t* data, int16_t* dest) = 0;

    /**
     * @brief Get the phase and confidence image.
     *
     * @param[in]  data       image data(cache data).
     * @param[out] phase      phase image.
     * @param[out] amplitude  amplitude image.
     * @param[out] confidence confidence image.
     */
    virtual bool getPhaseImage(const uint8_t* data, float* phase, float* amplitude, float* confidence) = 0;

    /**
     * @brief Get the platform of the system.
     */
    Arducam::Platform platform() const
    {
        return _platform;
    }
};

} // namespace Arducam

#endif
