#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "arducam_evk_cpp_sdk" for configuration "None"
set_property(TARGET arducam_evk_cpp_sdk APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(arducam_evk_cpp_sdk PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libarducam_evk_cpp_sdk.so.1.0.9"
  IMPORTED_SONAME_NONE "libarducam_evk_cpp_sdk.so.1"
  )

list(APPEND _IMPORT_CHECK_TARGETS arducam_evk_cpp_sdk )
list(APPEND _IMPORT_CHECK_FILES_FOR_arducam_evk_cpp_sdk "${_IMPORT_PREFIX}/lib/libarducam_evk_cpp_sdk.so.1.0.9" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
