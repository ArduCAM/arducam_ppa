#ifndef ARDUCAM_UVC_STEREO_FLASH_SDK_HPP
#define ARDUCAM_UVC_STEREO_FLASH_SDK_HPP

#include <cstdint>
#include <map>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace arducam::uvc_stereo {

/**
 * @brief Error codes used by C++ API.
 */
enum class ErrorCode {
    kOk = 0,                ///< Success – no error.
    kInvalidArgument,       ///< A function argument was invalid (e.g. empty JSON).
    kIoError,               ///< Generic I/O error (file system, USB transport).
    kDeviceInitFailed,      ///< Could not initialise the USB device handle.
    kDeviceReadFailed,      ///< Flash read operation failed.
    kDeviceWriteFailed,     ///< Flash write operation failed.
    kDeviceEraseFailed,     ///< Flash sector erase operation failed.
    kInvalidMagic,          ///< Flash header magic (0x41524455) mismatch.
    kUnsupportedVersion,    ///< Flash format version is not supported.
    kInvalidHeaderSize,     ///< Header size field is inconsistent.
    kInvalidTotalSize,      ///< Total payload size exceeds allowed bounds.
    kCrcMismatch,           ///< CRC-32 verification of the payload failed.
    kJsonError,             ///< JSON serialisation / deserialisation error.
    kInternalError,         ///< Unexpected internal error (bug).
    kUnsupportedCapability, ///< Device or firmware does not support a requested capability.
};

/**
 * @brief Non-throwing status object used by all API methods.
 */
class Status {
public:
    /** @brief Construct an Ok status (default). */
    Status() = default;

    /**
     * @brief Construct an error status.
     * @param code  The error code.
     * @param message  Human-readable description of the error.
     */
    Status(ErrorCode code, std::string message)
        : code_(code), message_(std::move(message)) {}

    /** @brief Factory that returns an Ok status. */
    static Status Ok() { return Status(); }

    /** @brief Return @c true when the status represents success. */
    bool ok() const noexcept { return code_ == ErrorCode::kOk; }

    /** @brief Return the error code. */
    ErrorCode code() const noexcept { return code_; }

    /** @brief Return the human-readable error message (empty on success). */
    const std::string &message() const noexcept { return message_; }

private:
    ErrorCode code_ = ErrorCode::kOk;
    std::string message_;
};

/**
 * @brief Result wrapper for returning either value or Status.
 */
template <typename T>
class Result {
public:
    /** @brief Construct a Result holding a failed Status. */
    Result(const Status &status) : status_(status) {}

    /** @overload */
    Result(Status &&status) : status_(std::move(status)) {}

    /** @brief Construct a Result holding a success value (copy). */
    Result(const T &value) : status_(Status::Ok()), value_(value) {}

    /** @brief Construct a Result holding a success value (move). */
    Result(T &&value) : status_(Status::Ok()), value_(std::move(value)) {}

    /** @brief Return @c true when the Result holds a value. */
    bool ok() const noexcept { return status_.ok(); }

    /** @brief Return the underlying Status. */
    const Status &status() const noexcept { return status_; }

    /**
     * @brief Access the stored value (const).
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    const T &value() const { return value_.value(); }

    /**
     * @brief Access the stored value (mutable).
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    T &value() { return value_.value(); }

    /**
     * @brief Move the stored value out of the Result.
     * @pre ok() must be @c true; otherwise behaviour is undefined.
     */
    T move_value() { return std::move(value_.value()); }

private:
    Status status_;
    std::optional<T> value_;
};

/**
 * @brief OpenCV VideoCapture backend identifiers supported by this SDK.
 *
 * The enum values intentionally match OpenCV's ``cv::VideoCaptureAPIs`` so
 * callers can pass ``static_cast<int>(backend)`` directly to
 * ``cv::VideoCapture(index, backend)``.
 */
enum class OpenCvBackend : int32_t {
    CAP_V4L2 = 200,
    CAP_DSHOW = 700,
    CAP_MSMF = 1400,
    CAP_GSTREAMER = 1800,
};

using OpenCvBackendIndexMap = std::map<OpenCvBackend, int32_t>;

/**
 * @brief Return the symbolic OpenCV backend name.
 *
 * Useful when displaying the entries stored in DeviceInfo::opencv_backend_indices.
 */
std::string_view opencv_backend_name(OpenCvBackend backend) noexcept;

/**
 * @brief Information about one discovered Arducam USB device.
 */
struct DeviceInfo {
    uint16_t vid = 0;           ///< USB Vendor ID.
    uint16_t pid = 0;           ///< USB Product ID.
    uint8_t bus_number = 0;     ///< USB bus number.
    uint8_t device_address = 0; ///< USB device address on the bus.
    std::string serial_number;  ///< USB serial number string (may be empty).
    std::string manufacturer;   ///< USB manufacturer descriptor.
    std::string product;        ///< USB product descriptor.
    std::string video_node;     ///< V4L2 video device node (e.g. ``/dev/video0``).
    std::string device_path;    ///< Sysfs device path.
    OpenCvBackendIndexMap opencv_backend_indices; ///< OpenCV backend -> index mapping.
};

/**
 * @brief Result returned by Device::read_json().
 */
struct ReadJsonResult {
    uint16_t version = 0;  ///< Flash format version.
    std::string json_utf8; ///< JSON payload (UTF-8).
};

/**
 * @brief Device capabilities that may be probed by open_device().
 */
enum class DeviceCapability : uint32_t {
    kFlashTransport = 1u << 0u,   ///< Sonix flash transport can be opened and read.
    kImuTransport = 1u << 1u,     ///< Retained for compatibility; open_device() ignores this bit.
    kFlashJsonContent = 1u << 2u, ///< Flash currently contains a valid JSON blob.
};

/**
 * @brief Options controlling which capabilities are checked by open_device().
 *
 * The default validates the flash transport without requiring the flash to
 * already contain calibration JSON. open_device() intentionally ignores
 * DeviceCapability::kImuTransport; call Device::open_imu() to check IMU
 * support.
 */
struct OpenDeviceOptions {
    uint32_t required_capabilities =
        static_cast<uint32_t>(DeviceCapability::kFlashTransport);
};

/** @brief Raw IMU sample returned by Device::read_imu(). */
struct ReadImuResult {
    uint64_t host_timestamp_ns = 0;   ///< Host monotonic timestamp in nanoseconds.
    uint32_t imu_timestamp_raw = 0;   ///< IMU firmware timestamp parsed from the raw payload.
    int16_t temperature_raw = 0; ///< Raw temperature register value.
    int16_t accel_x_raw = 0;     ///< Raw accelerometer X value.
    int16_t accel_y_raw = 0;     ///< Raw accelerometer Y value.
    int16_t accel_z_raw = 0;     ///< Raw accelerometer Z value.
    int16_t gyro_x_raw = 0;      ///< Raw gyroscope X value.
    int16_t gyro_y_raw = 0;      ///< Raw gyroscope Y value.
    int16_t gyro_z_raw = 0;      ///< Raw gyroscope Z value.
};

/**
 * @brief Opened device object returned after a selected DeviceInfo is probed.
 *
 * The object binds the selected USB identity and flash configuration. It does
 * not keep the Sonix flash handle open between calls because the vendor SDK
 * uses a single global device handle.
 */
class Device {
public:
    /** @brief Destructor releases the device object. */
    ~Device();

    Device(const Device &) = delete;
    Device &operator=(const Device &) = delete;

    /** @brief Move constructor transfers ownership of the device object. */
    Device(Device &&other) noexcept;

    /** @brief Move assignment transfers ownership of the device object. */
    Device &operator=(Device &&other) noexcept;

    /** @brief Return the selected device information. */
    const DeviceInfo &info() const noexcept;

    /** @brief Whether flash transport was successfully probed during open_device(). */
    bool has_flash_transport() const noexcept;

    /** @brief Whether IMU transport has been successfully opened. */
    bool has_imu_transport() const noexcept;

    /** @brief Read JSON from this device's flash. IMU must be closed. */
    Result<ReadJsonResult> read_json() noexcept;

    /**
     * @brief Write JSON to this device's flash.
     *
     * The IMU session must be closed before writing flash JSON.
     *
     * @warning Permanently erases the configured flash region
     *          (default: 0x51000).
     */
    Status write_json(std::string_view json_utf8) noexcept;

    /** @brief Open this device's persistent IMU session. */
    Status open_imu() noexcept;

    /** @brief Read one raw IMU sample from the opened IMU session. */
    Result<ReadImuResult> read_imu() noexcept;

    /** @brief Close this device's IMU session. Safe to call repeatedly. */
    Status close_imu() noexcept;

private:
    class Impl;
    std::unique_ptr<Impl> impl_;

    friend Result<Device> open_device(const DeviceInfo &device,
                                      const OpenDeviceOptions &options) noexcept;
    explicit Device(std::unique_ptr<Impl> impl) noexcept;
};

/**
 * @brief Options for converting raw IMU values to engineering units.
 *
 * Raw acceleration and angular velocity samples are divided by the configured
 * LSB-per-unit value.
 */
struct ImuConversionOptions {
    double temperature_offset_c = 25.0;
    double temperature_lsb_per_c = 128.0;
    double accel_lsb_per_g = 2048.0;
    double gyro_lsb_per_dps = 16.4;
};

/**
 * @brief Converted IMU values.
 */
struct ConvertedImuResult {
    uint64_t host_timestamp_ns = 0; ///< Host monotonic timestamp in nanoseconds.
    double temperature_c = 0.0;

    double accel_x_g = 0.0;
    double accel_y_g = 0.0;
    double accel_z_g = 0.0;

    double gyro_x_dps = 0.0;
    double gyro_y_dps = 0.0;
    double gyro_z_dps = 0.0;
};

/**
 * @brief Convert a raw IMU sample to engineering units.
 *
 * Temperature is converted using
 * @c temperature_offset_c + temperature_raw / temperature_lsb_per_c.
 * Acceleration and angular velocity are converted using their configured
 * scale factors. If a scale factor is zero, the corresponding converted
 * values remain 0 to avoid division by zero.
 */
Result<ConvertedImuResult> convert_imu(const ReadImuResult &raw,
                                       const ImuConversionOptions &options = {}) noexcept;

/**
 * @brief Scan the system for connected Arducam devices.
 */
Result<std::vector<DeviceInfo>> scan_devices() noexcept;

/**
 * @brief Probe and open a selected device.
 */
Result<Device> open_device(const DeviceInfo &device,
                           const OpenDeviceOptions &options = {}) noexcept;

} // namespace arducam::uvc_stereo

#endif // ARDUCAM_UVC_STEREO_FLASH_SDK_HPP
