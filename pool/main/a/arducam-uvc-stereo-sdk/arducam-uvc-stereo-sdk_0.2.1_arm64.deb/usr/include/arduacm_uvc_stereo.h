#ifndef ARDUCAM_UVC_STEREO_FLASH_H
#define ARDUCAM_UVC_STEREO_FLASH_H

#include <stddef.h>
#include <stdint.h>

#if !defined(ARDUCAM_UVC_STEREO_API)
#if defined(_WIN32)
#if defined(ARDUCAM_UVC_STEREO_BUILD_SHARED)
#define ARDUCAM_UVC_STEREO_API __declspec(dllexport)
#elif defined(ARDUCAM_UVC_STEREO_USE_SHARED)
#define ARDUCAM_UVC_STEREO_API __declspec(dllimport)
#else
#define ARDUCAM_UVC_STEREO_API
#endif
#elif defined(ARDUCAM_UVC_STEREO_BUILD_SHARED)
#define ARDUCAM_UVC_STEREO_API __attribute__((visibility("default")))
#else
#define ARDUCAM_UVC_STEREO_API
#endif
#endif

#if !defined(ARDUCAM_UVC_STEREO_DEPRECATED)
#if defined(_MSC_VER)
#define ARDUCAM_UVC_STEREO_DEPRECATED __declspec(deprecated)
#elif defined(__GNUC__) || defined(__clang__)
#define ARDUCAM_UVC_STEREO_DEPRECATED __attribute__((deprecated))
#else
#define ARDUCAM_UVC_STEREO_DEPRECATED
#endif
#endif

#define ARDUCAM_UVC_STEREO_VERSION_MAJOR 0
#define ARDUCAM_UVC_STEREO_VERSION_MINOR 2
#define ARDUCAM_UVC_STEREO_VERSION_PATCH 1

#define ARDUCAM_UVC_STEREO_DEFAULT_FLASH_MAGIC 0x41524455u
#define ARDUCAM_UVC_STEREO_DEFAULT_FLASH_ADDRESS 0x51000u
#define ARDUCAM_UVC_STEREO_DEFAULT_ERASE_SECTOR_SIZE 0x1000u
#define ARDUCAM_UVC_STEREO_DEFAULT_MAX_TOTAL_SIZE (64u * 1024u)
#define ARDUCAM_UVC_STEREO_DEFAULT_HEADER_MIN_SIZE 16u
#define ARDUCAM_UVC_STEREO_DEFAULT_HEADER_MAX_SIZE 256u
#define ARDUCAM_UVC_STEREO_FLASH_FORMAT_V0 0u
#define ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX 256u
#define ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX 512u
#define ARDUCAM_UVC_STEREO_OPENCV_BACKEND_INDEX_MAX 8u

typedef struct arducam_uvc_stereo_handle arducam_uvc_stereo_handle_t;
typedef struct arducam_uvc_stereo_device arducam_uvc_stereo_device_t;

typedef enum arducam_uvc_stereo_error_code {
    ARDUCAM_UVC_STEREO_OK = 0,
    ARDUCAM_UVC_STEREO_ERR_INVALID_ARGUMENT = 1,
    ARDUCAM_UVC_STEREO_ERR_IO_ERROR = 2,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_INIT_FAILED = 3,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_READ_FAILED = 4,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_WRITE_FAILED = 5,
    ARDUCAM_UVC_STEREO_ERR_DEVICE_ERASE_FAILED = 6,
    ARDUCAM_UVC_STEREO_ERR_INVALID_MAGIC = 7,
    ARDUCAM_UVC_STEREO_ERR_UNSUPPORTED_VERSION = 8,
    ARDUCAM_UVC_STEREO_ERR_INVALID_HEADER_SIZE = 9,
    ARDUCAM_UVC_STEREO_ERR_INVALID_TOTAL_SIZE = 10,
    ARDUCAM_UVC_STEREO_ERR_CRC_MISMATCH = 11,
    ARDUCAM_UVC_STEREO_ERR_JSON_ERROR = 12,
    ARDUCAM_UVC_STEREO_ERR_INTERNAL_ERROR = 13,
    ARDUCAM_UVC_STEREO_ERR_UNSUPPORTED_CAPABILITY = 14,
} arducam_uvc_stereo_error_code_t;

/**
 * @brief OpenCV VideoCapture backend identifiers supported by this SDK.
 *
 * The numeric values intentionally match OpenCV's cv::VideoCaptureAPIs so
 * callers can pass them directly to cv::VideoCapture(index, backend).
 */
typedef enum arducam_uvc_stereo_opencv_backend {
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_V4L2 = 200,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_DSHOW = 700,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_MSMF = 1400,
    ARDUCAM_UVC_STEREO_OPENCV_BACKEND_CAP_GSTREAMER = 1800
} arducam_uvc_stereo_opencv_backend_t;

typedef enum arducam_uvc_stereo_device_capability {
    ARDUCAM_UVC_STEREO_DEVICE_CAPABILITY_FLASH_TRANSPORT = 1u << 0,
    /* Retained for compatibility. arducam_uvc_stereo_open_device() ignores this bit. */
    ARDUCAM_UVC_STEREO_DEVICE_CAPABILITY_IMU_TRANSPORT = 1u << 1,
    ARDUCAM_UVC_STEREO_DEVICE_CAPABILITY_FLASH_JSON_CONTENT = 1u << 2
} arducam_uvc_stereo_device_capability_t;

/**
 * @brief One OpenCV backend/index pair for a discovered device.
 */
typedef struct arducam_uvc_stereo_opencv_backend_index_entry {
    arducam_uvc_stereo_opencv_backend_t backend;
    int32_t index;
} arducam_uvc_stereo_opencv_backend_index_entry_t;

typedef struct arducam_uvc_stereo_config {
    uint32_t flash_address;
    uint32_t erase_sector_size;
    uint32_t flash_magic;
    uint32_t max_total_size;
    uint16_t min_header_size;
    uint16_t max_header_size;
    int strict_crc;
    int verify_after_write;
} arducam_uvc_stereo_config_t;

typedef struct arducam_uvc_stereo_open_device_options {
    uint32_t required_capabilities;
} arducam_uvc_stereo_open_device_options_t;

/**
 * @brief Information about one discovered Arducam USB device.
 */
typedef struct arducam_uvc_stereo_device_info {
    uint16_t vid;
    uint16_t pid;
    uint8_t bus_number;
    uint8_t device_address;
    char serial_number[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char manufacturer[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char product[ARDUCAM_UVC_STEREO_DEVICE_TEXT_MAX];
    char video_node[ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX];
    char device_path[ARDUCAM_UVC_STEREO_DEVICE_PATH_MAX];
    size_t opencv_backend_index_count;
    arducam_uvc_stereo_opencv_backend_index_entry_t
        opencv_backend_indices[ARDUCAM_UVC_STEREO_OPENCV_BACKEND_INDEX_MAX];
} arducam_uvc_stereo_device_info_t;

/** @brief Raw IMU sample returned by arducam_uvc_stereo_device_read_imu(). */
typedef struct arducam_uvc_stereo_read_imu_result {
    uint64_t host_timestamp_ns;
    uint32_t imu_timestamp_raw;
    int16_t temperature_raw;
    int16_t accel_x_raw;
    int16_t accel_y_raw;
    int16_t accel_z_raw;
    int16_t gyro_x_raw;
    int16_t gyro_y_raw;
    int16_t gyro_z_raw;
} arducam_uvc_stereo_read_imu_result_t;

/**
 * @brief Options for converting raw IMU values.
 *
 * Temperature uses:
 * temperature_offset_c + temperature_raw / temperature_lsb_per_c.
 *
 * accel_lsb_per_g defaults to 2048.0, and gyro_lsb_per_dps defaults to 16.4.
 * Raw samples are divided by the configured LSB-per-unit value. If a scale
 * factor is zero, the corresponding converted values remain 0 to avoid
 * division by zero.
 */
typedef struct arducam_uvc_stereo_imu_conversion_options {
    double temperature_offset_c;
    double temperature_lsb_per_c;
    double accel_lsb_per_g;
    double gyro_lsb_per_dps;
} arducam_uvc_stereo_imu_conversion_options_t;

/**
 * @brief Converted IMU values.
 */
typedef struct arducam_uvc_stereo_converted_imu_result {
    uint64_t host_timestamp_ns;
    double temperature_c;
    double accel_x_g;
    double accel_y_g;
    double accel_z_g;
    double gyro_x_dps;
    double gyro_y_dps;
    double gyro_z_dps;
} arducam_uvc_stereo_converted_imu_result_t;

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Scan the system for connected Arducam devices.
 *
 * On success `*out_devices` points to a heap-allocated array of
 * `*out_count` arducam_uvc_stereo_device_info_t elements.
 * The caller **must** free it with arducam_uvc_stereo_free(), even when `*out_count == 0`.
 *
 * @param[out] out_devices  Receives the pointer to the device array.
 * @param[out] out_count    Receives the number of devices found.
 * @return ARDUCAM_UVC_STEREO_OK on success, or a non-zero arducam_uvc_stereo_error_code_t on failure.
 *
 * @code{.c}
 * arducam_uvc_stereo_device_info_t *devs = NULL;
 * size_t n = 0;
 * int32_t rc = arducam_uvc_stereo_scan_devices(&devs, &n);
 * if (rc != ARDUCAM_UVC_STEREO_OK || n == 0) { arducam_uvc_stereo_free(devs); return; }
 * arducam_uvc_stereo_device_info_t dev = devs[0];
 * arducam_uvc_stereo_free(devs);
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_scan_devices(
    arducam_uvc_stereo_device_info_t **out_devices,
    size_t *out_count);

ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_open_device_options_init_default(
    arducam_uvc_stereo_open_device_options_t *out_options);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_open_device(
    const arducam_uvc_stereo_device_info_t *device_info,
    const arducam_uvc_stereo_open_device_options_t *options,
    arducam_uvc_stereo_device_t **out_device);

ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_close_device(
    arducam_uvc_stereo_device_t *device);

ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_info(
    const arducam_uvc_stereo_device_t *device,
    arducam_uvc_stereo_device_info_t *out_device_info);

/**
 * @brief Read JSON from device flash. The device IMU session must be closed.
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_read_json(
    arducam_uvc_stereo_device_t *device,
    uint16_t *out_version,
    char **out_json_utf8,
    size_t *out_json_utf8_len);

/**
 * @brief Write JSON to device flash. The device IMU session must be closed.
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_write_json(
    arducam_uvc_stereo_device_t *device,
    const char *json_utf8,
    size_t json_utf8_len);

/**
 * @brief Open the device-owned persistent IMU session.
 *
 * If this device firmware does not support IMU, returns
 * ARDUCAM_UVC_STEREO_ERR_UNSUPPORTED_CAPABILITY.
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_open_imu(
    arducam_uvc_stereo_device_t *device);

/** @brief Read one raw IMU sample using the device's opened IMU session. */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_read_imu(
    arducam_uvc_stereo_device_t *device,
    arducam_uvc_stereo_read_imu_result_t *out_result);

/** @brief Close the device's IMU session. Passing a device with no session is safe. */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_device_close_imu(
    arducam_uvc_stereo_device_t *device);

/**
 * @brief Initialise IMU conversion options to defaults.
 */
ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_imu_conversion_options_init_default(
    arducam_uvc_stereo_imu_conversion_options_t *out_options);

/**
 * @brief Convert a raw IMU sample.
 *
 * Passing @c NULL for @p options uses default conversion options.
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_convert_imu(
    const arducam_uvc_stereo_read_imu_result_t *raw,
    const arducam_uvc_stereo_imu_conversion_options_t *options,
    arducam_uvc_stereo_converted_imu_result_t *out_result);

/**
 * @brief Return the symbolic OpenCV backend name.
 *
 * This is useful when displaying entries from
 * arducam_uvc_stereo_device_info_t::opencv_backend_indices.
 */
ARDUCAM_UVC_STEREO_API const char *arducam_uvc_stereo_opencv_backend_name(
    arducam_uvc_stereo_opencv_backend_t backend);

/**
 * @brief Retrieve the last error message on the calling thread.
 *
 * The returned pointer is valid until the next SDK call on the same thread.
 * Do **not** free it.
 *
 * @param[out] out_message     Receives a pointer to the error string.
 * @param[out] out_message_len Receives the byte length of the string.
 * @return ARDUCAM_UVC_STEREO_OK always.
 *
 * @code{.c}
 * const char *msg;
 * size_t len;
 * arducam_uvc_stereo_last_error_message(&msg, &len);
 * fprintf(stderr, "error: %.*s\n", (int)len, msg);
 * @endcode
 */
ARDUCAM_UVC_STEREO_API int32_t arducam_uvc_stereo_last_error_message(
    const char **out_message,
    size_t *out_message_len);

/**
 * @brief Free memory allocated by the SDK.
 *
 * Pass the pointer returned by arducam_uvc_stereo_scan_devices() or
 * arducam_uvc_stereo_device_read_json().
 * Passing @c NULL is safe and has no effect.
 *
 * @param[in] ptr Pointer to free, or @c NULL.
 */
ARDUCAM_UVC_STEREO_API void arducam_uvc_stereo_free(void *ptr);

#ifdef __cplusplus
}
#endif

#endif // ARDUCAM_UVC_STEREO_FLASH_H
