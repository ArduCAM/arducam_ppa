#ifndef __RGBIR_REMOSAIC_H__
#define __RGBIR_REMOSAIC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

enum RGBIR_FORMAT {
    BGGI,
    GIRG,
    RGGI,
    GRIG,
    IGGB,
    GBIG,
    GIBG,
};

int remosaic(uint8_t *buffer, uint32_t input_width, uint32_t input_height, uint8_t **output_bayer, uint8_t **output_ir, enum RGBIR_FORMAT rgbir_mode);
int remosaic16(uint16_t *buffer, uint32_t input_width, uint32_t input_height, uint16_t **output_bayer, uint16_t **output_ir, enum RGBIR_FORMAT rgbir_mode);


#ifdef __cplusplus
}
#endif

#endif